#ifndef _MyServosDef_H_
#define _MyServosDef_H_

#include "MyStruct.h"

extern myServo hipL;
extern myServo hipR;
extern myServo thighL;
extern myServo thighR;
extern myServo calfL;
extern myServo calfR;
extern myServo ankleL;
extern myServo ankleR;

#endif