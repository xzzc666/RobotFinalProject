#include "MyServo.h"

void TaskDelay(void* myClass)
{
  MyServo* servoData = static_cast<MyServo*>(myClass);
  
  int pinWrite = servoData->myValue.writePin;
  
  while(1)
  {
    int delayTime = servoData->myValue.delayTime;
    
    digitalWrite(pinWrite,1);
    vTaskDelay(delayTime / (1000 * portTICK_PERIOD_MS)); 
    digitalWrite(pinWrite,0);
    vTaskDelay((20000 - delayTime) / (1000 * portTICK_PERIOD_MS)); 
    
  }
}

MyServo::MyServo()
{
}

void MyServo::Setup(struct servoInit initValue)
{
  this->myValue = initValue;
  this->ServoDrive(90);
  pinMode(this->myValue.readPin,0);
  pinMode(this->myValue.writePin,1);
  xTaskCreate(TaskDelay, this->myValue.taskDelayName, 128, this, 1, NULL);
  
}

void MyServo::ServoDrive(int degree)
{
  this->myValue.delayTime = map(degree,0,180,500,2500);
}

