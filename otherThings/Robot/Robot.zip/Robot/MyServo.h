#ifndef _MyServo_H_
#define _MyServo_H_
#include "Arduino.h"
#include "MyStruct.h"

void TaskDelay(void* myClass);

class MyServo
{
  public:
    MyServo();
    void Setup(struct servoInit initValue);
    void ServoDrive(int degree);

    struct servoInit myValue;
};



#endif
