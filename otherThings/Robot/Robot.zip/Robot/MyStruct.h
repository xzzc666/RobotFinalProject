#ifndef _MyStruct_H_
#define _MyStruct_H_
#include "Arduino.h"

struct servoInit 
{
  const char* taskDelayName = "delayTaskName";
  int delayTime = 0;
  int readPin = 1;
  int writePin = 2;

};

#endif
